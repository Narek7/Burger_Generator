# data_collector.py

class DataCollector:
    def __init__(self, env, resources):
        self.env = env
        self.resources = resources
        self.bestellungen = {}
        self.zuarbeiter_nutzung = []
        self.burgermeister_nutzung = []

    def erfasse_bestellung(self, bestellung_id, bestellzeit, abholzeit, zutaten):
        self.bestellungen[bestellung_id] = {
            'bestellzeit': bestellzeit,
            'abholzeit': abholzeit,
            'zutaten': zutaten,
            'vorarbeit_start': None,
            'vorarbeit_ende': None,
            'zubereitung_start': None,
            'zubereitung_ende': None,
            'abholzeit_real': None
        }

    def erfasse_vorarbeit(self, bestellung_id, start, ende):
        self.bestellungen[bestellung_id]['vorarbeit_start'] = start
        self.bestellungen[bestellung_id]['vorarbeit_ende'] = ende

    def erfasse_zubereitung(self, bestellung_id, start, ende):
        self.bestellungen[bestellung_id]['zubereitung_start'] = start
        self.bestellungen[bestellung_id]['zubereitung_ende'] = ende

    def erfasse_abholung(self, bestellung_id, abholzeit_real):
        self.bestellungen[bestellung_id]['abholzeit_real'] = abholzeit_real

    def zuarbeiter_nutzung_start(self, start):
        self.zuarbeiter_nutzung.append({'start': start, 'ende': None})

    def zuarbeiter_nutzung_ende(self, ende):
        for eintrag in self.zuarbeiter_nutzung:
            if eintrag['ende'] is None:
                eintrag['ende'] = ende
                break

    def burgermeister_nutzung_start(self, start):
        self.burgermeister_nutzung.append({'start': start, 'ende': None})

    def burgermeister_nutzung_ende(self, ende):
        for eintrag in self.burgermeister_nutzung:
            if eintrag['ende'] is None:
                eintrag['ende'] = ende
                break

    def analyse_ergebnisse(self):
        # Durchschnittliche Prozesszeit für die Produktion eines Burgers
        gesamtzeiten = []
        for bestellung in self.bestellungen.values():
            if bestellung['abholzeit_real'] is not None:
                dauer = bestellung['abholzeit_real'] - bestellung['bestellzeit']
                gesamtzeiten.append(dauer)
        durchschnitt_prozesszeit = sum(gesamtzeiten) / len(gesamtzeiten)
        print(f"\nDurchschnittliche Prozesszeit pro Burger: {durchschnitt_prozesszeit:.2f} Minuten")

        # Engpässe analysieren (Auslastung der Ressourcen)
        zuarbeiter_auslastung = self.berechne_auslastung(self.zuarbeiter_nutzung)
        burgermeister_auslastung = self.berechne_auslastung(self.burgermeister_nutzung)
        print(f"Auslastung der Zuarbeiter*innen: {zuarbeiter_auslastung * 100:.2f}%")
        print(f"Auslastung des Burgermeisters: {burgermeister_auslastung * 100:.2f}%")

        # Leerlaufzeiten berechnen
        zuarbeiter_leerlauf = 1 - zuarbeiter_auslastung
        burgermeister_leerlauf = 1 - burgermeister_auslastung
        print(f"Leerlaufzeit der Zuarbeiter*innen: {zuarbeiter_leerlauf * 100:.2f}%")
        print(f"Leerlaufzeit des Burgermeisters: {burgermeister_leerlauf * 100:.2f}%")

        # Durchschnittliche Wartezeit der Studierenden
        wartezeiten = []
        for bestellung in self.bestellungen.values():
            if bestellung['abholzeit_real'] is not None:
                wartezeit = bestellung['abholzeit_real'] - bestellung['bestellzeit'] - 30
                wartezeiten.append(wartezeit)
        durchschnitt_wartezeit = sum(wartezeiten) / len(wartezeiten)
        print(f"Durchschnittliche Wartezeit der Studierenden: {durchschnitt_wartezeit:.2f} Minuten")

    def berechne_auslastung(self, nutzung):
        gesamtzeit = self.env.now
        belegte_zeit = sum(eintrag['ende'] - eintrag['start'] for eintrag in nutzung if eintrag['ende'] is not None)
        auslastung = belegte_zeit / (gesamtzeit * len(self.resources['zuarbeiter'].users))
        return min(auslastung, 1.0)

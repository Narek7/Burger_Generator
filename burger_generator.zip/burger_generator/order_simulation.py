# order_simulation.py

from processes import bestellung_prozess
import random
import simpy


def bestellungen_erstellen(env, resources, data):
    """Generiert Bestellungen zwischen 11:00 und 14:00 Uhr und startet deren Prozesse."""
    aktuelle_zeit = 0  # Startzeitpunkt in Minuten nach 11:00 Uhr
    endzeit = 180      # Endzeitpunkt in Minuten nach 11:00 Uhr (14:00 Uhr)

    bestellung_id = 0
    while aktuelle_zeit < endzeit:
        bestellzeit = env.now  # Aktuelle Simulationszeit

        # Generiere einen zufälligen Burger basierend auf den analysierten Verteilungen
        zutaten = generiere_zufallsburger()

        # Starte den Prozess für diese Bestellung
        env.process(bestellung_prozess(env, bestellung_id, zutaten, resources, data))

        # Zeit bis zur nächsten Bestellung (Normalverteilung mit Mittelwert 8 Sekunden und Std-Abweichung 105 Sekunden)
        wartezeit = max(1, abs(random.normalvariate(8, 105))) / 60  # Umrechnung in Minuten
        aktuelle_zeit += wartezeit
        bestellung_id += 1

        # Überprüfen, ob die nächste Bestellung nach 14:00 Uhr wäre
        if aktuelle_zeit >= endzeit:
            break

        yield env.timeout(wartezeit)


def generiere_zufallsburger():
    """Generiert einen Burger basierend auf den Wahrscheinlichkeiten aus der CSV-Datei."""
    zutaten = {}

    # Bun ist immer vorhanden
    zutaten['bun'] = 1

    # Patty
    r = random.random()
    if r < 0.523:
        zutaten['patty'] = 1
    else:
        zutaten['patty'] = 2

    # Gewürz
    zutaten['gewuerz'] = get_zutaten_anzahl('gewuerz')

    # Käse
    zutaten['kaese'] = get_zutaten_anzahl('kaese')

    # Bacon
    zutaten['bacon'] = get_zutaten_anzahl('bacon')

    # Salat
    zutaten['salat'] = get_zutaten_anzahl('salat')

    # Gemüse
    zutaten['gemuese'] = get_zutaten_anzahl('gemuese')

    # Sauce
    zutaten['sauce'] = get_zutaten_anzahl('sauce')

    # Pommes
    zutaten['pommes_bestellt'] = random.random() < 0.5  # 50% bestellen Pommes

    return zutaten


def get_zutaten_anzahl(zutat):
    """Gibt die Anzahl der jeweiligen Zutat basierend auf den Wahrscheinlichkeiten zurück."""
    r = random.random()
    if zutat == 'gewuerz':
        if r < 0.347:
            return 0
        elif r < 0.347 + 0.393:
            return 1
        elif r < 0.347 + 0.393 + 0.200:
            return 2
        elif r < 0.347 + 0.393 + 0.200 + 0.057:
            return 3
        else:
            return 5
    elif zutat == 'kaese':
        if r < 0.385:
            return 0
        elif r < 0.385 + 0.390:
            return 1
        elif r < 0.385 + 0.390 + 0.168:
            return 2
        elif r < 0.385 + 0.390 + 0.168 + 0.055:
            return 3
        else:
            return 5
    elif zutat == 'bacon':
        if r < 0.341:
            return 0
        elif r < 0.341 + 0.429:
            return 1
        elif r < 0.341 + 0.429 + 0.228:
            return 2
        else:
            return 3
    elif zutat == 'salat':
        if r < 0.158:
            return 0
        elif r < 0.158 + 0.702:
            return 1
        elif r < 0.158 + 0.702 + 0.139:
            return 2
        else:
            return 3
    elif zutat == 'gemuese':
        if r < 0.136:
            return 0
        elif r < 0.136 + 0.278:
            return 1
        elif r < 0.136 + 0.278 + 0.255:
            return 2
        elif r < 0.136 + 0.278 + 0.255 + 0.188:
            return 3
        elif r < 0.136 + 0.278 + 0.255 + 0.188 + 0.097:
            return 4
        else:
            return 5
    elif zutat == 'sauce':
        if r < 0.001:
            return 0
        elif r < 0.001 + 0.162:
            return 1
        elif r < 0.001 + 0.162 + 0.692:
            return 2
        else:
            return 3
    else:
        return 0

# processes.py

import random
import simpy
import logging
from datetime import timedelta


def format_time(env, minutes=None):
    """Formatiert Minuten als Uhrzeit im HH:MM:SS-Format ab 11:00 Uhr."""
    if minutes is None:
        minutes = env.now
    start_time = timedelta(hours=11)  # 11:00 Uhr als Startzeit
    current_time = start_time + timedelta(minutes=minutes)
    return str(current_time)


def bestellung_prozess(env, bestellung_id, zutaten, resources, data):
    """Simuliert den gesamten Prozess einer Bestellung."""
    bestellzeit = env.now
    abholzeit = bestellzeit + 30  # Abholzeit ist 30 Minuten nach Bestellung

    # Speichere Bestelldaten
    data.erfasse_bestellung(bestellung_id, bestellzeit, abholzeit, zutaten)

    # Starte Vorarbeitstheke
    yield env.process(vorarbeitstheke(env, bestellung_id, zutaten, resources, data))

    # Starte Zubereitungstheke
    yield env.process(zubereitungstheke(env, bestellung_id, zutaten, resources, abholzeit, data))

    # Abholung
    abholzeit_real = env.now
    data.erfasse_abholung(bestellung_id, abholzeit_real)

    log_event(
        env,
        f"Bestellung {bestellung_id}: Burger zur Abholung bereit um {format_time(env)} (Dauer: {env.now - bestellzeit:.2f} Minuten)"
    )


def vorarbeitstheke(env, bestellung_id, zutaten, resources, data):
    """Prozess an der Vorarbeitstheke."""
    start = env.now
    log_event(env, f"Bestellung {bestellung_id}: Start Vorarbeitstheke um {format_time(env)}")

    with resources['zuarbeiter'].request() as req_zuarbeiter:
        yield req_zuarbeiter
        data.zuarbeiter_nutzung_start(env.now)

        # Aufwand für Zuarbeiter*innen (10-30 Sekunden, Gamma-Verteilung)
        aufwand = random.gammavariate(10, 2) / 60  # Umrechnung in Minuten
        yield env.timeout(aufwand)

        # Zubereitungszeit für warme Zutaten (6-10 Minuten, Uniformverteilung)
        zubereitungszeit = random.uniform(6, 10)
        yield env.timeout(zubereitungszeit)

        data.zuarbeiter_nutzung_ende(env.now)

    ende = env.now
    data.erfasse_vorarbeit(bestellung_id, start, ende)
    log_event(env, f"Bestellung {bestellung_id}: Ende Vorarbeitstheke um {format_time(env)}")


def zubereitungstheke(env, bestellung_id, zutaten, resources, abholzeit, data):
    """Prozess an der Zubereitungstheke."""
    # Wartezeit bis frühestens 5 Minuten vor Abholzeit
    startzeitpunkt = max(abholzeit - 5, env.now)
    if startzeitpunkt > env.now:
        yield env.timeout(startzeitpunkt - env.now)

    start = env.now
    log_event(env, f"Bestellung {bestellung_id}: Start Zubereitungstheke um {format_time(env)}")

    with resources['burgermeister'].request() as req_burgermeister:
        yield req_burgermeister
        data.burgermeister_nutzung_start(env.now)

        # Toasten des Buns (40 Sekunden)
        yield env.timeout(40 / 60)

        # Belegen pro kalter Zutat (5 Sekunden, Normal(1,5))
        kalte_zutaten_anzahl = zutaten['gewuerz'] + zutaten['kaese'] + zutaten['salat'] + zutaten['gemuese'] + zutaten['sauce']
        for _ in range(kalte_zutaten_anzahl):
            belegzeit = max(1, random.normalvariate(5, 1)) / 60  # Mindestens 1 Sekunde
            yield env.timeout(belegzeit)

        # Fehlerwahrscheinlichkeit von 5%
        if random.random() < 0.05:
            log_event(env, f"Bestellung {bestellung_id}: Fehler bei der Zubereitung, Neustart erforderlich um {format_time(env)}")
            data.burgermeister_nutzung_ende(env.now)
            # Neustart des gesamten Prozesses
            yield env.process(bestellung_prozess(env, bestellung_id, zutaten, resources, data))
            return

        # Verpacken und Etikettieren (10-20 Sekunden, Uniformverteilung)
        verpackungszeit = random.uniform(10, 20) / 60

        # Zusätzliche Zeit, wenn Pommes bestellt wurden
        if zutaten['pommes_bestellt']:
            verpackungszeit += random.uniform(15, 30) / 60

        yield env.timeout(verpackungszeit)

        data.burgermeister_nutzung_ende(env.now)

    ende = env.now
    data.erfasse_zubereitung(bestellung_id, start, ende)
    log_event(env, f"Bestellung {bestellung_id}: Ende Zubereitungstheke um {format_time(env)}")


def log_event(env, event):
    """Schreibt das Event in die Logdatei und gibt es in der Konsole aus."""
    zeit = format_time(env)
    message = f"[{zeit}] {event}"
    print(message)
    logging.info(message)

# main.py

from env_setup import setup_environment
from order_simulation import bestellungen_erstellen


def run_simulation():
    """Startet die gesamte Simulation von 11:00 bis 14:30 Uhr."""
    env, resources, data = setup_environment()

    # Starte die Bestellungserstellung um 11:00 Uhr
    env.process(bestellungen_erstellen(env, resources, data))

    # Simulation laufen lassen bis 14:30 Uhr (in Minuten ab 11:00 Uhr)
    env.run(until=210)  # 14:30 Uhr entspricht 210 Minuten nach 11:00 Uhr

    # Nach der Simulation: Analyse der gesammelten Daten
    data.analyse_ergebnisse()


if __name__ == "__main__":
    run_simulation()
